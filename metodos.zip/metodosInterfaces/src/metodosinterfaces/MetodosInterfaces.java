/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package metodosinterfaces;

public class MetodosInterfaces {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        B b = new B();
        //A a = b;
        T t = b;
        hacerSaludar(b);
        //hacerSaludar(a);
        //hacerSaludar(t);
        
        
    }
    public static void hacerSaludar(H algo){
        algo.saludar();
        
    }
}
