/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metodosinterfaces;

/**
 *
 * @author francisco
 */
public class A  implements T{
    
    public void saludar(){
        System.out.println("hola soy clase A");
    }
    
}
