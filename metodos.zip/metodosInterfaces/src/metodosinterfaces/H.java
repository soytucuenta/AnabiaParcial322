/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package metodosinterfaces;

/**
 *
 * @author francisco
 */
public interface H {
        default void saludar(){
        System.out.println("soy la interfaz H en un metodo default");
    }
}
