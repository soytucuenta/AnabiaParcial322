/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metodosinterfaces;

/**
 *
 * @author francisco
 */
public class B extends A {
    /**
    public void saludar(){
        System.out.println("soy la clase B");
    }
    */
    @Override
    public void saludar(){
        super.saludar();
        System.out.println("saludar de B");
    }
    
}
